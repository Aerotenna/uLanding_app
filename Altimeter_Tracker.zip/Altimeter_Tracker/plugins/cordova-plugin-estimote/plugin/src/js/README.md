# Estimote JavaScript Plugin

Cordova/PhoneGap plugin for Estimote Beacons and Estimote Stickers.

<img src="http://evomedia.evothings.com/2015/02/beacons-in-box.jpg">
