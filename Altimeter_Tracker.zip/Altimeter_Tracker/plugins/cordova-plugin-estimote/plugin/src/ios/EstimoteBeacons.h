#import <Cordova/CDV.h>

@interface EstimoteBeacons : CDVPlugin

- (EstimoteBeacons*) pluginInitialize;
- (void) onReset;

@end
